package com.example.hw1_cellular_infinate_runner_game_v2;

public class GameManager {

    private int rows;
    private int cols;
    private int live;
    private int playerPlace;


    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getColumns() {
        return cols;
    }

    public void setColumns(int columns) {
        this.cols = columns;
    }

    public int getLive() {
        return live;
    }

    public void setLive(int live) {
        this.live = live;
    }

    public void reduceLife(int lifes){
        if(lifes>0) {
            setLive(lifes - 1);
        }
    }

    public int getPlayerPlace() {
        return playerPlace;
    }

    public void setPlayerPlace(int playerPosition) {
        this.playerPlace = playerPosition;
    }
}
