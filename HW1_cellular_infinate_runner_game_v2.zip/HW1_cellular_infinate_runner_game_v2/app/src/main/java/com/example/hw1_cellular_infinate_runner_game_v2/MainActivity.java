package com.example.hw1_cellular_infinate_runner_game_v2;

import android.content.Context;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    AppCompatImageView game_IMG_background;
    private ShapeableImageView[] game_IMG_hearts;
    private ShapeableImageView[][] game_IMG_log;
    private ShapeableImageView[] game_IMG_frog;
    private FloatingActionButton game_FAB_left;
    private FloatingActionButton game_FAB_right;
    private Random r;
    Timer timer = new Timer();
    GameManager gameManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        findViews();
        r = new Random();
        gameManager = new GameManager();
        gameManager.setPlayerPlace(1);
        gameManager.setLive(3);

        refreshUI();
        checkPlayerPlace();
    }

    private void refreshUI() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    checkForCollision();
                    updateHeartsUi();
                    logsGoDownInMatrix();
                });
            }
        }, 2000, 1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }

    @Override
    protected void onStop() {
        super.onStop();
        timer.cancel();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        refreshUI();
    }

    private void checkForCollision() {
        boolean isCollision = game_IMG_log[3][gameManager.getPlayerPlace()].getVisibility() == View.VISIBLE;

        if (isCollision) {
            handleCollision();
        }
    }

    private void handleCollision() {
        if (gameManager.getLive() > 1) {
            gameManager.reduceLife(gameManager.getLive());
        } else {
            restartLives();
        }

        msgLifeLost();
        vibrateDevice();
    }

    private void msgLifeLost() {
        Toast.makeText(this, "1 life lost", Toast.LENGTH_SHORT).show();
    }

    private void vibrateDevice() {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) {
            vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }

    private void logsGoDownInMatrix() {
        for (int i = 0; i < 3; i++) {
            for (int j = 3; j > 0; j--) {
                game_IMG_log[j][i].setVisibility(game_IMG_log[j - 1][i].getVisibility());
            }
            game_IMG_log[0][i].setVisibility(View.INVISIBLE);
        }
        int randomColumn = r.nextInt(3);
        game_IMG_log[0][randomColumn].setVisibility(View.VISIBLE);
    }

    private void checkPlayerPlace() {
        game_FAB_left.setOnClickListener(view -> movePlayer(true));
        game_FAB_right.setOnClickListener(view -> movePlayer(false));
    }

    private void movePlayer(boolean isLeft) {
        game_IMG_frog[gameManager.getPlayerPlace()].setVisibility(View.INVISIBLE);
        if (isLeft && gameManager.getPlayerPlace() > 0) {
            gameManager.setPlayerPlace(gameManager.getPlayerPlace() - 1);

        } else if (!isLeft && gameManager.getPlayerPlace() < 2) {
            gameManager.setPlayerPlace(gameManager.getPlayerPlace() + 1);
        }
        game_IMG_frog[gameManager.getPlayerPlace()].setVisibility(View.VISIBLE);
    }

    private void findViews() {
        game_IMG_background = findViewById(R.id.game_IMG_background);
        game_FAB_left = findViewById(R.id.game_FAB_left);
        game_FAB_right = findViewById(R.id.game_FAB_right);
        initHearts();
        initObstaclesMatrix();
        initPlayerPosition();
    }

    private void initHearts() {
        game_IMG_hearts = new ShapeableImageView[]{
                findViewById(R.id.game_IMG_heart1),
                findViewById(R.id.game_IMG_heart2),
                findViewById(R.id.game_IMG_heart3),
        };
    }

    private void initObstaclesMatrix() {
        game_IMG_log = new ShapeableImageView[][]{
                {findViewById(R.id.game_IMG_log_1), findViewById(R.id.game_IMG_log_2), findViewById(R.id.game_IMG_log_3)},
                {findViewById(R.id.game_IMG_log_4), findViewById(R.id.game_IMG_log_5), findViewById(R.id.game_IMG_log_6)},
                {findViewById(R.id.game_IMG_log_7), findViewById(R.id.game_IMG_log_8), findViewById(R.id.game_IMG_log_9)},
                {findViewById(R.id.game_IMG_log_10), findViewById(R.id.game_IMG_log_11), findViewById(R.id.game_IMG_log_12)},
        };
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                game_IMG_log[i][j].setVisibility(View.INVISIBLE);
            }
        }
    }

    private void initPlayerPosition() {
        game_IMG_frog = new ShapeableImageView[]{
                findViewById(R.id.game_IMG_frog_left),
                findViewById(R.id.game_IMG_frog_center),
                findViewById(R.id.game_IMG_frog_right),
        };
        game_IMG_frog[0].setVisibility(View.INVISIBLE);
        game_IMG_frog[2].setVisibility(View.INVISIBLE);
    }

    private void updateHeartsUi() {
        if (gameManager.getLive() < game_IMG_hearts.length) {
            game_IMG_hearts[gameManager.getLive()].setVisibility(View.INVISIBLE);
        }
    }

    private void restartLives() {
        gameManager.setLive(3);
        game_IMG_hearts[0].setVisibility(View.VISIBLE);
        game_IMG_hearts[1].setVisibility(View.VISIBLE);
        game_IMG_hearts[2].setVisibility(View.VISIBLE);
    }
}
